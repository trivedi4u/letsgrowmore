# Flutter Face Detector ML

This is the source code for Flutter Face Detector ML.<br>

## App Features
- Capture Image Or Select From Gallery.<br>
- Detecting All Faces In Image And Draw Rect.<br><br>

For Step By Step Guide Follow Video Tutorial:

- [Flutter ML | Flutter Face Detection From Image Complete Tutorial](https://youtu.be/b9v4DqmK2fk)

## Links used in project:

- [Firebase Core](https://bit.ly/3lSrhDt)
- [Firebase ML Vision](http://bit.ly/38LkHJo)
- [Implementations](http://bit.ly/37T4930)
<br><br>

Feel Free to copy the code and use it.<br><br>
Don't forget to star the repo and like the video :)
