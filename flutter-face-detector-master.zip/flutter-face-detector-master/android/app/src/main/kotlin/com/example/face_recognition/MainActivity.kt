package com.example.face_recognition

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
